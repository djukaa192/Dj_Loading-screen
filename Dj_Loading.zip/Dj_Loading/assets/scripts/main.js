/* global $, particlesJS */
$(function () {
    /* ---------------------------------------------------- */
    /* 1.  PARTICLES                                         */
    particlesJS.load('particles-js', 'assets/scripts/particles.json');

    /* ---------------------------------------------------- */
    /* 2.  CUSTOM CURSOR                                     */
    const $cursor = $('#custom-cursor');
    $(document).on('mousemove', e => {
        $cursor.css({ top: e.pageY, left: e.pageX, display: 'block', opacity: 1 });
    }).on('mouseleave', () => $cursor.css({ opacity: 0 }));

    /* ---------------------------------------------------- */
    /* 3.  MUSIC PLAYER                                      */
    const playlist = [
        { title: 'bolt',           artist: 'bolt',    cover: 'https://files.catbox.moe/5qw4mt.png', video: 'https://files.catbox.moe/n2lww2.mp4' },
        { title: 'Good very',    artist: 'Good very', cover: 'https://files.catbox.moe/5qw4mt.png', video: 'https://files.catbox.moe/kne6xq.mp4' },
        { title: 'versace',      artist: 'Versace',     cover: 'https://files.catbox.moe/5qw4mt.png', video: 'https://files.catbox.moe/myfsu3.mp4' },
        { title: 'LOM', artist: 'LOM', cover: 'https://files.catbox.moe/5qw4mt.png', video: 'https://files.catbox.moe/fgf6jc.mp4' },
        { title: 'BOLJA SAM OD ZDRAVLJA',  artist: 'BOLJA SAM OD ZDRAVLJA', cover: 'https://files.catbox.moe/5qw4mt.png', video: 'https://files.catbox.moe/ytg7a7.mp4' },
        { title: 'LUMPE LUMPE',                 artist: 'LUMPE LUMPE',         cover: 'https://files.catbox.moe/5qw4mt.png', video: 'https://files.catbox.moe/sthmpt.mp4' },
    ];
    let current = Math.floor(Math.random() * playlist.length);

    const $video   = $('#bg-video');
    const $title   = $('.song-title');
    const $artist  = $('.song-artist');
    const $cover   = $('.song-cover');
    const $playBtn = $('#play-pause');
    const $vol     = $('#volume-slider');
    const $prog    = $('#progress-bar');
    const $cur     = $('#current-time');
    const $dur     = $('#duration');

    function fmt(t) {
        if (isNaN(t)) return '0:00';
        const m = Math.floor(t / 60), s = Math.floor(t % 60);
        return `${m}:${s < 10 ? '0' : ''}${s}`;
    }

    function loadSong(i) {
        const s = playlist[i];
        $title.text(s.title);
        $artist.text(s.artist);
        $cover.attr('src', s.cover);
        $video.attr('src', s.video)[0].load();
        $video[0].play();
        $playBtn.text('⏸');
    }

    $('#prev-song').on('click', () => { current = (current - 1 + playlist.length) % playlist.length; loadSong(current); });
    $('#next-song').on('click', () => { current = (current + 1) % playlist.length;              loadSong(current); });
    $playBtn.on('click', () => {
        const v = $video[0];
        if (v.paused) { v.play(); $playBtn.text('⏸'); } else { v.pause(); $playBtn.text('▶'); }
    });
    $vol.on('input', e => $video[0].volume = e.target.value / 100);
    $video.on('timeupdate', () => {
        const v = $video[0];
        $prog.val((v.currentTime / v.duration) * 100 || 0);
        $cur.text(fmt(v.currentTime));
        $dur.text(fmt(v.duration));
    });
    $video.on('ended', () => { current = (current + 1) % playlist.length; loadSong(current); });
    $prog.on('input', e => $video[0].currentTime = ($video[0].duration * e.target.value) / 100);
    $(document).on('keydown', e => {
        if (e.key === ' ') { e.preventDefault(); $playBtn.click(); }
        if (e.key === 'ArrowRight') $('#next-song').click();
        if (e.key === 'ArrowLeft')  $('#prev-song').click();
    });
    loadSong(current);

    /* ---------------------------------------------------- */
    /* 4.  GAME LAYER HANDLING                               */
    const $gameIcon = $('#game-toggle');
    const $ttt = $('#tictactoe-container');
    const $menu = $('#game-selection-container');

    function hideGames() { $ttt.add($menu).hide(); }

    $gameIcon.on('click', () => {
        if ($menu.is(':visible') || $ttt.is(':visible')) {
            hideGames();
        } else {
            $menu.fadeIn();
        }
    });

    /* ----------------  TIC‑TAC‑TOE  ---------------- */
    const winning = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
    let state, player, active, diff, playerTurn;

    function newBoard() { state = Array(9).fill(''); player = 'X'; active = false; playerTurn = true; }

    function selectDifficulty(d) {
        diff = d;
        $('#difficulty-select').hide();
        $('.tictactoe-grid, #reset-game').show();
        $('.status-message').text('Your turn (X)');
        active = true;
        playerTurn = true;
    }

    function winner(p) { return winning.some(c => c.every(i => state[i] === p)); }
    function draw() { return state.every(c => c); }

    function randMove() { const e = state.map((c, i) => c ? null : i).filter(i => i !== null); return e[Math.floor(Math.random() * e.length)]; }
    function bestMove() {
        let best = -Infinity, move;
        state.forEach((c, i) => {
            if (!c) {
                state[i] = 'O';
                const score = minimax(state, 0, false);
                state[i] = '';
                if (score > best) { best = score; move = i; }
            }
        });
        return move;
    }
    function minimax(b, depth, max) {
        if (winner('O')) return 10 - depth;
        if (winner('X')) return depth - 10;
        if (draw()) return 0;
        if (max) {
            let best = -Infinity;
            b.forEach((c, i) => { if (!c) { b[i] = 'O'; best = Math.max(best, minimax(b, depth + 1, false)); b[i] = ''; } });
            return best;
        } else {
            let best = Infinity;
            b.forEach((c, i) => { if (!c) { b[i] = 'X'; best = Math.min(best, minimax(b, depth + 1, true)); b[i] = ''; } });
            return best;
        }
    }

    function renderTTT() {
        $('.game-cell').each((_, el) => {
            const i = $(el).data('cell-index');
            $(el).text(state[i]);
        }).css('pointer-events', idx => 'auto');
    }

    function handleCell() {
        const i = $(this).data('cell-index');
        if (!playerTurn || !active || state[i]) return;
        state[i] = player;
        renderTTT();
        if (winner(player)) { active = false; $('.status-message').text('You win!'); return; }
        if (draw()) { active = false; $('.status-message').text("It's a draw!"); return; }
        playerTurn = false;
        $('.status-message').text("Computer's turn...");
        setTimeout(() => {
            let move;
            switch (diff) {
                case 'easy': move = randMove(); break;
                case 'medium': move = Math.random() < 0.5 ? randMove() : bestMove(); break;
                default: move = bestMove();
            }
            state[move] = 'O';
            renderTTT();
            if (winner('O')) { active = false; $('.status-message').text('Computer wins!'); }
            else if (draw()) { active = false; $('.status-message').text("It's a draw!"); }
            else { playerTurn = true; $('.status-message').text('Your turn (X)'); }
        }, 500);
    }

    function showTTT() {
        newBoard();
        const grid = Array(9).fill('').map((_, i) => `<div class="game-cell" data-cell-index="${i}"></div>`).join('');
        $ttt.html(`
            <h2>Tic‑Tac‑Toe</h2>
            <button id="back-from-ttt" class="back-btn">← Back</button>
            <div id="difficulty-select">
                <p>Select Difficulty:</p>
                <button class="difficulty-btn" data-diff="easy">Easy</button>
                <button class="difficulty-btn" data-diff="medium">Medium</button>
                <button class="difficulty-btn" data-diff="hard">Hard</button>
            </div>
            <div class="status-message"></div>
            <div class="tictactoe-grid" style="display:none;">${grid}</div>
            <button id="reset-game" style="display:none;">Reset Game</button>
        `);
        $('#back-from-ttt').on('click', () => { $ttt.hide(); $menu.fadeIn(); });
        $('.difficulty-btn').on('click', e => selectDifficulty($(e.currentTarget).data('diff')));
        $ttt.on('click', '.game-cell', handleCell);
        $('#reset-game').on('click', showTTT);
        $ttt.fadeIn();
    }

    $('#select-ttt').on('click', () => { $menu.hide(); showTTT(); });

    /* Hide games when UI is toggled off */
    $('.ui-toggle').on('click', () => {
        $('.content-container, .social-links, .music-player, #game-toggle, .controller-icon').fadeToggle();
        $('.eye-icon').toggleClass('hidden');
        if ($('.eye-icon').hasClass('hidden')) hideGames();
    });
});